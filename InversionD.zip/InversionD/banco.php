<?php

class banco //extends AnotherClass implements Interface
{

    public function pagar()
    {
        echo "El banco paga";
    }
    
}



?>