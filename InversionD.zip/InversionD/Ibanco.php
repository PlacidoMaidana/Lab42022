<?php

interface Ibanco
{

    function pagar();
}




?>