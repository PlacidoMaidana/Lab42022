    <div id="header">
      <div id="logo">
        <h1>logo here</h1>
        <h4>have your punchline here</h4>
      </div>
      <div id="links">
        <ul>
          <li><a href="../Invention/index.php">Home</a></li>
          <li><a href="../Invention/lista.php">Lista</a></li>
          <!-- <li><a href="../Invention/tecnologi.php">Technology</a></li> -->
          <li><a href="../Invention/contact.php">Formulario</a></li>
          <li><a href="../Invention/index.php?carga=1">Cargar</a></li>
          <li><a href="../Invention/index.php?limpiar=1">Limpiar</a></li>
          <li><a href="../Invention/index.php?cerrarSecion=1">Cerrar</a></li>
        </ul>
      </div>
    </div>