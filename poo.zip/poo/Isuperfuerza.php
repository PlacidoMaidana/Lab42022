<?php

interface superfuerza
{

function fuerza();

}







?>