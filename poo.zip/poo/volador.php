<?php

interface volador
{
    function volar();
   

}





?>