<?php

interface Iacuatico
{
    function respiraBAgua();

}




?>